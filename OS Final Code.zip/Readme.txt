-- clkUtilities.h contains clk functions, it should be included anywhere the clock functions are used
-- queueUtilities.h contains queue functions,
-- to get time call
    getClk();
--You can use make file to build and run your project
-To compile your project write on terminal
make
-To run your project write on terminal
make run
-To clean your project use
make clean
-if you added a file to your project add it to the build section in the Makefile
-always start the line with a tab in Makefile, it is its syntax